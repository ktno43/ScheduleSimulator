﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.RegularExpressions;

namespace ScheduleGenerator
{
    public class Course
    {
        [Display(Name = "Course Section")]
        public String courseSec { get; set; }

        [Display(Name = "Course Name")]
        public String courseName { get; set; }

        [Display(Name = "Course Number")]
        public String courseNum { get; set; }

        [Display(Name = "Course Location")]
        public String courseLoc { get; set; }

        [Display(Name = "Course Days")]
        public String courseDay { get; set; }

        [Display(Name = "Course Start Time")]
        public String cStartTime { get; set; }

        [Display(Name = "Course End Time")]
        public String cEndTime { get; set; }

        [Display(Name = "Course Instructor")]
        public String courseInstr { get; set; }

        public Course()
        {
            courseSec = String.Empty;
            courseName = String.Empty;
            courseNum = String.Empty;
            courseLoc = String.Empty;
            courseDay = String.Empty;
            cStartTime = String.Empty;
            cEndTime = String.Empty;
            courseInstr = String.Empty;
        }

        public Course(String[] line)
        {
            courseSec = line[0];
            courseName = line[1];
            courseNum = line[2];
            courseLoc = line[3];
            courseDay = line[4];
            cStartTime = line[5];
            cEndTime = line[6];
            courseInstr = line[7];
        }

        public Course(String courseSection, String courseName, String courseNum, String location, String day, String startTime, String endTime, String courseInstr)
        {
            this.courseSec = courseSection;
            this.courseName = courseName;
            this.courseNum = courseNum;
            this.courseLoc = location;
            this.courseDay = day;
            this.cStartTime = startTime;
            this.cEndTime = endTime;
            this.courseInstr = courseInstr;

        }

        protected String[] getCourseInfo()
        {
            String[] arrCourseInfo = {
                this.courseSec,
                this.courseName,
                this.courseNum,
                this.courseLoc,
                this.courseDay,
                this.cStartTime,
                this.cEndTime,
                this.courseInstr };

            return arrCourseInfo;
        }

        public Boolean isOverlap(Course c2)
        {
            if ((!isUnknown(this) && (!isUnknown(c2))))
            {
                String[] arrC1 = parseTime(this);
                String[] arrC2 = parseTime(c2);

                if (isDayConflict(this, c2) && isTimeConflict(arrC1, arrC2))
                {
                    return true;
                }
            }

            return false;
        }

        private Boolean isDayConflict(Course c1, Course c2)
        {
            String c1Day = Regex.Replace(c1.courseDay, ".{2}", "$0,").TrimEnd(',');
            String c2Day = Regex.Replace(c2.courseDay, ".{2}", "$0,").TrimEnd(',');

            String[] arrC1Day = c1Day.Split(',');
            String[] arrC2Day = c2Day.Split(',');

            if (arrC1Day.Length > arrC2Day.Length)
            {
                if (arrC2Day.Intersect(arrC1Day).Any())
                {
                    return true;
                }
            }

            else
            {
                if (arrC1Day.Intersect(arrC2Day).Any())
                {
                    return true;
                }
            }
            return false;
        }


        private Boolean isTimeConflict(String[] t1, String[] t2)
        {
            int t1HrS = Int32.Parse(t1[0]);
            int t1MinS = Int32.Parse(t1[1]);
            DateTime t1TimeS = getTime(t1HrS, t1MinS, t1[3]);

            int t1HrE = Int32.Parse(t1[3]);
            int t1MinE = Int32.Parse(t1[4]);
            DateTime t1TimeE = getTime(t1HrE, t1MinE, t1[5]);


            int t2HrS = Int32.Parse(t2[0]);
            int t2MinS = Int32.Parse(t2[1]);
            DateTime t2TimeS = getTime(t2HrS, t2MinS, t2[3]);

            int t2HrE = Int32.Parse(t2[3]);
            int t2MinE = Int32.Parse(t2[4]);
            DateTime t2TimeE = getTime(t2HrE, t2MinE, t2[5]);

            return (t1TimeS <= t2TimeE) && (t2TimeS <= t1TimeE);
        }


        private DateTime getTime(int hour, int minute, String amPm)
        {
            int year = 2019;
            int month = 9;
            int day = 23;

            if ((amPm.Equals("pm") || amPm.Equals("PM")) && hour < 12)
            {
                hour += 12;
            }

            return new DateTime(year, month, day, hour, minute, 00);
        }

        private Boolean isUnknown(Course c)
        {
            return (c.cStartTime.Equals("TBA")) &&
                (c.courseDay.Equals("TBA"));
        }

        private String[] parseTime(Course c)
        {
            String[] timeArr = new String[6];

            String sHr = c.cStartTime.Substring(0, 2);
            String sMin = c.cStartTime.Substring(3, 2);
            String sAmPm = c.cStartTime.Substring(5, 2);

            String eHr = c.cEndTime.Substring(0, 2);
            String eMin = c.cEndTime.Substring(3, 2);
            String eAmPm = c.cEndTime.Substring(5, 2);

            timeArr[0] = sHr;
            timeArr[1] = sMin;
            timeArr[2] = sAmPm;

            timeArr[3] = eHr;
            timeArr[4] = eMin;
            timeArr[5] = eAmPm;

            return timeArr;
        }
    }
}
