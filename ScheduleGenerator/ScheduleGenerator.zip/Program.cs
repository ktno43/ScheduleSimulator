﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ScheduleGenerator
{
    static class Program
    {

        static void Main(string[] args)
        {
            OracleConfiguration.TnsAdmin = @"F:\Projects\AspNetCore\ConsoleApps\ScheduleGenerator\OracleWallet\";

            CourseDataAccessLayer cDac = new CourseDataAccessLayer();
            List<List<Course>> courseWant = new List<List<Course>>();

            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 490"));
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 490L"));
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 485"));
            courseWant.Add(cDac.getCourseByTbl("tblAnth", "ANTH 310"));

            /*
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 490")); //4
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 490L")); //7
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 310"));//3
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 333"));//3
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 482"));//2
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 541"));//1
            */


            List<CourseBreak> breakList = new List<CourseBreak>();
            CourseBreak cb = new CourseBreak("MoWeSa");

            breakList.Add(cb);

            Stopwatch stopWatch = new Stopwatch();

            stopWatch.Start();
            GenerateSchedule(courseWant, breakList);
            stopWatch.Stop();


            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}h {1:00}m {2:00}.{3:00}s",
                ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);

            Console.WriteLine("\r\n\r\nElapsed time to generate schedule(s): " + elapsedTime);

            Console.WriteLine("\r\n\r\n\r\nProgram Ending. . . ");
            Console.Write("Press ENTER to exit ----> ");
            Console.ReadLine();

            Environment.Exit(0);
        }

        private static void GenerateSchedule(List<List<Course>> courseWant, List<CourseBreak> breakList)
        {
            Dictionary<String, List<int>> cwDictionary = new Dictionary<String, List<int>>();

            for (int i = 0; i < courseWant.Count; i++)
            {
                List<int> courseNumList = new List<int>();

                for (int j = 0; j < courseWant[i].Count; j++)
                {
                    courseNumList.Add(j);
                }

                cwDictionary.Add(String.Format("Course{0}", i.ToString()), courseNumList);
            }

            List<List<Course>> validSched = new List<List<Course>>();
            List<List<int>> cwNumList = new List<List<int>>();

            foreach (KeyValuePair<String, List<int>> entry in cwDictionary)
            {
                cwNumList.Add(entry.Value);
            }

            var possibleCombos = CartesianProduct(cwNumList);

            foreach (var combo in possibleCombos)
            {
                List<Course> tempSched = new List<Course>();

                for (int k = 0; k < courseWant.Count; k++)
                {
                    tempSched.Add(courseWant[k][combo.ElementAt(k)]);
                }

                if (!IsConflict(tempSched) && !IsBreakConflict(tempSched, breakList))
                {
                    validSched.Add(tempSched);
                }
            }

            PrintSchedule(courseWant, validSched);
        }

        private static void PrintSchedule(List<List<Course>> courseWant, List<List<Course>> validSched)
        {
            int totalSchedules = 1;
            for (int i = 0; i < courseWant.Count; i++)
            {
                totalSchedules *= courseWant[i].Count;
            }

            Console.WriteLine("Possible schedule(s): " + validSched.Count + " out of " + totalSchedules + " possible");
            int schedNum = 1;
            foreach (List<Course> sched in validSched)
            {
                String schedRes = String.Empty;
                for (int l = 0; l < courseWant.Count; l++)
                {
                    if (l < (courseWant.Count - 1))
                    {
                        schedRes += sched[l].courseNum;
                        schedRes += ", ";
                    }

                    else
                    {
                        schedRes += sched[l].courseNum;
                    }
                }
                Console.Write(schedNum + ")\t" + schedRes + "\r\n");
                schedNum++;
            }
        }

        private static IEnumerable<IEnumerable<T>> CartesianProduct<T>(this IEnumerable<IEnumerable<T>> sequences)
        {
            // base case: 
            IEnumerable<IEnumerable<T>> result = new[] { Enumerable.Empty<T>() };
            foreach (var sequence in sequences)
            {
                var s = sequence; // don't close over the loop variable 
                                  // recursive case: use SelectMany to build the new product out of the old one 
                result =
                    from seq in result
                    from item in s
                    select seq.Concat(new[] { item });
            }
            return result;
        }

        private static IEnumerable<IEnumerable<T>> CartesianProduct2<T>(this IEnumerable<IEnumerable<T>> sequences)
        {
            IEnumerable<IEnumerable<T>> emptyProduct = new[] { Enumerable.Empty<T>() };
            return sequences.Aggregate(
                emptyProduct,
                (accumulator, sequence) =>
                from acc in accumulator
                from item in sequence
                select acc.Concat(new[] { item }));
        }

        private static Boolean IsBreakConflict(List<Course> courseList, List<CourseBreak> breakList)
        {
            Boolean isEmpty = !breakList.Any();

            if (!isEmpty)
            {
                for (int i = 0; i < courseList.Count; i++)
                {
                    for (int j = 0; j < breakList.Count; j++)
                    {
                        if (courseList[i].IsOverlap(breakList[j]))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;

        }

        private static Boolean IsConflict(List<Course> courseList)
        {
            if (courseList.Count == 1)
                return false;


            int valid = 0;
            int numTuples = 0;
            var baseList = new List<int>();

            for (int i = 0; i < courseList.Count; i++)
            {
                baseList.Add(i);
            }

            var tuples = from i1 in baseList
                         from i2 in baseList
                         where i1 < i2
                         select Tuple.Create(i1, i2);


            foreach (var tuple in tuples)
            {
                numTuples += 1;
                if (!(courseList[tuple.Item1].IsOverlap(courseList[tuple.Item2])))
                {
                    valid++;
                }
            }
            return valid != numTuples;

        }
    }
}
