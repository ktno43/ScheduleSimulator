﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ScheduleGenerator
{
    static class Program
    {

        static void Main(string[] args)
        {
            RunProgram();

            Console.WriteLine("\r\n\r\n\r\nProgram Ending. . . ");
            Console.Write("Press ENTER to exit ----> ");
            Console.ReadLine();

            Environment.Exit(0);
        }

        private static void RunProgram()
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();

            OracleConfiguration.TnsAdmin = @"F:\Projects\AspNetCore\ConsoleApps\ScheduleGenerator\OracleWallet\";

            CourseDataAccessLayer cDac = new CourseDataAccessLayer();
            Dictionary<String, List<Course>> cwDictionary = new Dictionary<String, List<Course>>();

            List<List<Course>> courseWant = new List<List<Course>>();
            List<CourseBreak> breakList = new List<CourseBreak>();

            AddToDictionary(cwDictionary, "COMP 490", cDac.getCourseByTbl("tblComp", "COMP 490"));
            AddToDictionary(cwDictionary, "COMP 490L", cDac.getCourseByTbl("tblComp", "COMP 490L"));
            AddToDictionary(cwDictionary, "COMP 485", cDac.getCourseByTbl("tblComp", "COMP 485"));
            AddToDictionary(cwDictionary, "ANTH 310", cDac.getCourseByTbl("tblAnth", "ANTH 310"));
            // AddToDictionary(cwDictionary, "ANTH 310", cDac.getCourseByTbl("tblAnth", "ANTH 310"));

            foreach (KeyValuePair<String, List<Course>> entry in cwDictionary)
            {
                courseWant.Add(entry.Value);
            }

            /*
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 490")); //4
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 490L")); //7
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 310"));//3
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 333"));//3
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 482"));//2
            courseWant.Add(cDac.getCourseByTbl("tblComp", "COMP 541"));//1
            */


            //CourseBreak cb2 = new CourseBreak("MoTuWeTrFrSa");
            //breakList.Add(cb2);

            // CourseBreak cb = new CourseBreak("MoWeSa");
            //breakList.Add(cb);


            CourseBreak cbM = new CourseBreak("Mo");
            CourseBreak cbW = new CourseBreak("We");
            CourseBreak cbS = new CourseBreak("Sa");
            breakList.Add(cbM);
            breakList.Add(cbW);
            breakList.Add(cbS);


            GenerateSchedule(courseWant, breakList);

            stopWatch.Stop();

            TimeSpan ts = stopWatch.Elapsed;
            string elapsedTime = String.Format("{0:00}h {1:00}m {2:00}.{3:00}s",
                ts.Hours, ts.Minutes, ts.Seconds, ts.Milliseconds / 10);

            Console.WriteLine("\r\n\r\nElapsed time to generate schedule(s): " + elapsedTime);
        }

        private static void AddToDictionary(Dictionary<String, List<Course>> cwDictionary, String key, List<Course> value)
        {
            if (!cwDictionary.ContainsKey(key))
            {
                cwDictionary.Add(key, value);
            }

            else
            {
                Console.WriteLine("Course " + key + " added already!  Only added once.\r\n");
            }
        }

        private static void GenerateSchedule(List<List<Course>> courseWant, List<CourseBreak> breakList)
        {
            Dictionary<String, List<int>> cwDictionary = new Dictionary<String, List<int>>();

            for (int i = 0; i < courseWant.Count; i++)
            {
                List<int> courseNumList = new List<int>();

                for (int j = 0; j < courseWant[i].Count; j++)
                {
                    courseNumList.Add(j);
                }
                cwDictionary.Add(String.Format("Course{0}", i.ToString()), courseNumList);
            }

            List<List<Course>> validSched = new List<List<Course>>();
            List<List<int>> cwNumList = new List<List<int>>();

            foreach (KeyValuePair<String, List<int>> entry in cwDictionary)
            {
                cwNumList.Add(entry.Value);
            }

            var possibleCombos = CartesianProduct(cwNumList);

            foreach (var combo in possibleCombos)
            {
                List<Course> tempSched = new List<Course>();

                for (int k = 0; k < courseWant.Count; k++)
                {
                    tempSched.Add(courseWant[k][combo.ElementAt(k)]);
                }

                if (!IsConflict(tempSched, breakList))
                {
                    validSched.Add(tempSched);
                }
            }

            PrintSchedule(courseWant, validSched);
        }

        private static void PrintSchedule(List<List<Course>> courseWant, List<List<Course>> validSched)
        {
            int totalSchedules = 1;
            for (int i = 0; i < courseWant.Count; i++)
            {
                totalSchedules *= courseWant[i].Count;
            }

            int possibleSchedules = 0;

            Boolean isEmpty = !validSched.Any();

            if (!isEmpty)
            {
                possibleSchedules = validSched.Count;
            }

            Console.WriteLine("Possible schedule(s): " + possibleSchedules + " out of " + totalSchedules + " possible");
            int schedNum = 1;

            if (possibleSchedules > 0)
            {
                foreach (List<Course> sched in validSched)
                {
                    String schedRes = String.Empty;
                    for (int l = 0; l < courseWant.Count; l++)
                    {
                        if (l < (courseWant.Count - 1))
                        {
                            schedRes += sched[l].courseNum;
                            schedRes += ", ";
                        }

                        else
                        {
                            schedRes += sched[l].courseNum;
                        }
                    }
                    Console.Write(schedNum + ")\t" + schedRes + "\r\n");
                    schedNum++;
                }
            }

            else
            {
                Console.WriteLine("No possible schedules found");
            }
        }

        private static IEnumerable<IEnumerable<T>> CartesianProduct<T>(this IEnumerable<IEnumerable<T>> sequences)
        {
            // base case: 
            IEnumerable<IEnumerable<T>> result = new[] { Enumerable.Empty<T>() };
            foreach (var sequence in sequences)
            {
                var s = sequence; // don't close over the loop variable 
                                  // recursive case: use SelectMany to build the new product out of the old one 
                result =
                    from seq in result
                    from item in s
                    select seq.Concat(new[] { item });
            }
            return result;
        }

        private static IEnumerable<IEnumerable<T>> CartesianProduct2<T>(this IEnumerable<IEnumerable<T>> sequences)
        {
            IEnumerable<IEnumerable<T>> emptyProduct = new[] { Enumerable.Empty<T>() };
            return sequences.Aggregate(
                emptyProduct,
                (accumulator, sequence) =>
                from acc in accumulator
                from item in sequence
                select acc.Concat(new[] { item }));
        }

        private static Boolean IsConflict(List<Course> courseList, List<CourseBreak> breakList)
        {
            Boolean isBreakLstEmpty = !breakList.Any();

            if (courseList.Count == 1)
                return false;


            int valid = 0;
            int numTuples = 0;
            var baseList = new List<int>();

            for (int i = 0; i < courseList.Count; i++)
            {
                baseList.Add(i);

                if (!isBreakLstEmpty)
                {
                    for (int j = 0; j < breakList.Count; j++)
                    {
                        if (courseList[i].IsOverlap(breakList[j]))
                        {
                            return true;
                        }
                    }
                }
            }

            var tuples = from i1 in baseList
                         from i2 in baseList
                         where i1 < i2
                         select Tuple.Create(i1, i2);

            foreach (var tuple in tuples)
            {
                numTuples++;
                if (!courseList[tuple.Item1].IsOverlap(courseList[tuple.Item2]))
                {
                    valid++;
                }
            }
            return valid != numTuples;
        }
    }
}
