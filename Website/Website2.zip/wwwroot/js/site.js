﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.
$(".dropdown-menu a").click(function () {
    $(this).parents(".dropdown").find('.btn').html($(this).text());
    $(this).parents(".dropdown").find('.btn').val($(this).data('value'));

    var subjTitle = $(this).text();


    subjTitle = subjTitle.substring(1, subjTitle.indexOf("-")).trim().replace(/([^a-z0-9]+)/gi, '');

    var tblPref = 'tbl';
    var tblName = tblPref.concat(subjTitle);
});