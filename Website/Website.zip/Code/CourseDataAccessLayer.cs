﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace ScheduleSimulator.Code
{
    public class CourseDataAccessLayer
    {
        //ORACLE INSTANCE CLIENT KYLE.ORCL
        private string connectionString = null;

        public CourseDataAccessLayer()
        {
            // connectionString = "Data Source=csuncoursesdb_high;User Id=ADMIN;Password=Password123!";
            connectionString = ConfigurationManager.AppSetting["ConnectionStrings:OracleConnection"];
        }

        public List<String> getSubj()
        {
            List<String> lstSubject = new List<String>();
            String tblSubj = ConfigurationManager.AppSetting["tblSubject:key"];
            String subject = String.Empty;

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "select subject from " + tblSubj;

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            subject = reader["Subject"].ToString();
                            lstSubject.Add(subject);
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstSubject;
        }

        public List<Course> getCourseByTbl(String tblName)
        {
            List<Course> lstCourse = new List<Course>();

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "select section,name,CourseNum,Location,Day,StartTime,EndTime,Instructor from " + tblName + " ORDER BY SECTION";

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            Course myCourse = new Course();

                            myCourse.courseSec = reader["Section"].ToString();
                            myCourse.courseName = reader["Name"].ToString();
                            myCourse.courseNum = reader["CourseNum"].ToString();
                            myCourse.courseLoc = reader["Location"].ToString();
                            myCourse.courseDay = reader["Day"].ToString();
                            myCourse.cStartTime = reader["StartTime"].ToString();
                            myCourse.cEndTime = reader["EndTime"].ToString();
                            myCourse.courseInstr = reader["Instructor"].ToString();

                            lstCourse.Add(myCourse);

                            //   Response.WriteAsync("Employee First Name: " + reader.GetString(0) + "\n");
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstCourse;
        }

    }
}
