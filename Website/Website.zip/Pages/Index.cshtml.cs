using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ScheduleSimulator.Code;

namespace ScheduleSimulator.Pages
{
    public class IndexModel : PageModel
    {
        CourseDataAccessLayer cDal = new CourseDataAccessLayer();

        public List<String> lstSubject { get; set; }
        public string Message { get; set; }

        public void OnGet()
        {

            lstSubject = cDal.getSubj();
            Message = "HOME PAGE HERE";
        }
    }
}