﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;

namespace ScheduleTester

{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            OracleConfiguration.TnsAdmin = "C:\\Users\\Jorg3\\Source\\Repos\\SchedulerSimulator\\SchedulerSimulator\\OracleConnection\\Wallet";
            CourseDataAccessLayer cDac = new CourseDataAccessLayer();

           List <Course> compList = cDac.getCourseByTbl("tblComp", "COMP 100");
           
        }
    }
}
