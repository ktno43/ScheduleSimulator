using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ScheduleSimulator.Code;
using HtmlAgilityPack;

namespace ScheduleSimulator.Pages
{
    public class IndexModel : PageModel
    {
        private CourseDataAccessLayer cDal { get; set; }

        public String lastUpdated { get; set; }

        public List<String> lstSubject { get; set; }

        public List<String> lstProf { get; set; }

        public List<List<Course>> lstValidSched { get; set; }

        private void FixIllegalChar(ref String refStr)
        {
            String invalidChars = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars()); // Get a string of invalid characters

            foreach (char c in invalidChars)
            {
                refStr = refStr.Replace(c.ToString(), String.Empty); // Remove invalid characters
            }
        }

        [HttpGet]
        public void OnGet()
        {
            cDal = new CourseDataAccessLayer();
            lstSubject = cDal.GetSubj();
            lastUpdated = cDal.GetUpdateDate();
            lstProf = cDal.GetProf();
        }

        [HttpPost]
        public JsonResult OnPostSubjChange(String selVal)
        {
            cDal = new CourseDataAccessLayer();
            List<String> lstCourse = new List<String>();
            String subjName = selVal;

            if (subjName != null)
            {
                String validSubj = (subjName.Substring(0, subjName.IndexOf('-')).Trim()).Replace(" ", String.Empty);
                FixIllegalChar(ref validSubj); // Fix any illegal characters

                lstCourse = cDal.GetUniqueCourseBySubj(validSubj);
            }

            return new JsonResult(lstCourse);
        }


        [HttpPost]
        public JsonResult OnPostProfChange(String selVal)
        {
            cDal = new CourseDataAccessLayer();
            List<String> lstCourse = new List<String>();
            String profName = selVal;

            if (profName != null)
            {

                lstCourse = cDal.GetUniqueCourseByProf(profName);
            }

            return new JsonResult(lstCourse);
        }

        [HttpPost]
        public JsonResult OnPostSubjProfChange(String selVal)
        {
            String subjName = selVal;
            List<String> lstCourse = new List<String>();

            if (subjName != null)
            {
                String validSec = (subjName.Substring(0, subjName.IndexOf('-')).Trim());
                cDal = new CourseDataAccessLayer();

                lstCourse = cDal.GetProfBySec(validSec);

            }
                return new JsonResult(lstCourse);       
        }


        [HttpPost]
        public JsonResult OnPostGenSched(String[] courseWant, String[] breaks, Boolean cbOpen)
        {
            cDal = new CourseDataAccessLayer();
            List<List<Course>> lstCourseWant = new List<List<Course>>();
            List<CourseBreak> lstBreaks = new List<CourseBreak>();

            for (int i = 0; i < courseWant.Length; i++)
            {
                var html2 = courseWant[i];
                var htmlDoc2 = new HtmlDocument();
                htmlDoc2.LoadHtml(html2);

                if (courseWant[i].Contains("<br>"))
                {
                    String profName = String.Empty;

                    HtmlNode brNode = htmlDoc2.DocumentNode.SelectNodes("//br").First();
                    profName = brNode.NextSibling.InnerText.Trim();

                    var innerText = String.Join("", htmlDoc2.DocumentNode.SelectNodes("//text()[normalize-space()]").
                           Select(t => t.InnerText));

                    int idxOfNum = innerText.IndexOfAny("0123456789".ToCharArray());
                    int idxOfDash = innerText.IndexOf('-');
                    String courseName = innerText.Substring(0, idxOfDash).Trim();

                    List<Course> currentSec = cDal.GetSectionByCourseAndProf(courseName, profName);
                    lstCourseWant.Add(currentSec);
                }

                else
                {
                    var innerText = String.Join("", htmlDoc2.DocumentNode.SelectNodes("//text()[normalize-space()]").
                                               Select(t => t.InnerText));

                    int idxOfNum = innerText.IndexOfAny("0123456789".ToCharArray());
                    int idxOfDash = innerText.IndexOf('-');
                    String courseName = innerText.Substring(0, idxOfDash).Trim();
                    List<Course> currentSec = cDal.GetSectionByCourse(courseName);

                    lstCourseWant.Add(currentSec);
                }
            }

            for (int j = 0; j < breaks.Length; j++)
            {
                var html = breaks[j];

                var htmlDoc = new HtmlDocument();
                htmlDoc.LoadHtml(html);

                int idxBreak = 0;
                String days = String.Empty;
                String time = String.Empty;

                foreach (HtmlNode br in htmlDoc.DocumentNode.SelectNodes("//br"))
                {
                    if (idxBreak == 0)
                    {
                        days = br.NextSibling.InnerText.Trim();
                    }

                    else
                    {
                        time = br.NextSibling.InnerText.Trim();
                    }

                    idxBreak++;
                }
                String[] splitDay = days.Split(' ');
                String[] splitTime = time.Split(" to ");
                for (int k = 0; k < splitDay.Length; k++)
                {
                    CourseBreak cBreak = new CourseBreak(splitDay[k], splitTime[0], splitTime[1]);

                    lstBreaks.Add(cBreak);
                }
            }


            List<List<Course>> validSched = GenerateSchedule(lstCourseWant, lstBreaks, cbOpen);
            lstValidSched = validSched;

            return new JsonResult(validSched);
        }

        private static String CleanFileName(String fileName)
        {
            return Path.GetInvalidFileNameChars().Aggregate(fileName, (current, c) => current.Replace(c.ToString(), String.Empty));
        }

        public List<List<Course>> GenerateSchedule(List<List<Course>> courseWant, List<CourseBreak> breakList, Boolean cbOpen)
        {
            Dictionary<String, List<int>> cwDictionary = new Dictionary<String, List<int>>();

            for (int i = 0; i < courseWant.Count; i++)
            {
                List<int> courseNumList = new List<int>();

                for (int j = 0; j < courseWant[i].Count; j++)
                {
                    courseNumList.Add(j);
                }
                cwDictionary.Add(String.Format("Course{0}", i.ToString()), courseNumList);
            }

            List<List<Course>> validSched = new List<List<Course>>();
            List<List<int>> cwNumList = new List<List<int>>();

            foreach (KeyValuePair<String, List<int>> entry in cwDictionary)
            {
                cwNumList.Add(entry.Value);
            }

            var possibleCombos = CartesianProduct(cwNumList);

            foreach (var combo in possibleCombos)
            {
                List<Course> tempSched = new List<Course>();

                for (int k = 0; k < courseWant.Count; k++)
                {
                    tempSched.Add(courseWant[k][combo.ElementAt(k)]);
                }

                if (!IsConflict(tempSched, breakList, cbOpen))
                {
                    validSched.Add(tempSched);
                }
            }

            return PrintSchedule(courseWant, validSched);
        }

        private List<List<Course>> PrintSchedule(List<List<Course>> courseWant, List<List<Course>> validSched)
        {
            int totalSchedules = 1;
            for (int i = 0; i < courseWant.Count; i++)
            {
                totalSchedules *= courseWant[i].Count;
            }

            int possibleSchedules = 0;

            Boolean isEmpty = !validSched.Any();

            if (!isEmpty)
            {
                possibleSchedules = validSched.Count;
            }

            Console.WriteLine("Possible schedule(s): " + possibleSchedules + " out of " + totalSchedules + " possible");
            int schedNum = 1;

            if (possibleSchedules > 0)
            {
                foreach (List<Course> sched in validSched)
                {
                    String schedRes = String.Empty;
                    for (int l = 0; l < courseWant.Count; l++)
                    {
                        if (l < (courseWant.Count - 1))
                        {
                            schedRes += sched[l].courseNum;
                            schedRes += ", ";
                        }

                        else
                        {
                            schedRes += sched[l].courseNum;
                        }
                    }
                    Console.Write(schedNum + ")\t" + schedRes + "\r\n");
                    schedNum++;
                }
            }

            else
            {
                Console.WriteLine("No possible schedules found");
            }

            return validSched;
        }

        private IEnumerable<IEnumerable<T>> CartesianProduct<T>(IEnumerable<IEnumerable<T>> sequences)
        {
            // base case: 
            IEnumerable<IEnumerable<T>> result = new[] { Enumerable.Empty<T>() };
            foreach (var sequence in sequences)
            {
                var s = sequence; // don't close over the loop variable 
                                  // recursive case: use SelectMany to build the new product out of the old one 
                result =
                    from seq in result
                    from item in s
                    select seq.Concat(new[] { item });
            }

            return result;
        }

        private IEnumerable<IEnumerable<T>> CartesianProduct2<T>(IEnumerable<IEnumerable<T>> sequences)
        {
            IEnumerable<IEnumerable<T>> emptyProduct = new[] { Enumerable.Empty<T>() };
            return sequences.Aggregate(
                emptyProduct,
                (accumulator, sequence) =>
                from acc in accumulator
                from item in sequence
                select acc.Concat(new[] { item }));
        }

        private Boolean IsConflict(List<Course> courseList, List<CourseBreak> breakList, Boolean cbOpen)
        {
            Boolean isBreakLstEmpty = !breakList.Any();

            if (courseList.Count == 1 && breakList.Count == 0)
            {
                if (cbOpen)
                {
                    if (!courseList[0].IsOpen(courseList[0]))
                    {
                        return true;
                    }
                }

                return false;
            }

            int valid = 0;
            int numTuples = 0;
            var baseList = new List<int>();

            for (int i = 0; i < courseList.Count; i++)
            {
                baseList.Add(i);

                if (cbOpen)
                {
                    if (!courseList[i].IsOpen(courseList[i]))
                    {
                        return true;
                    }
                }

                if (!isBreakLstEmpty)
                {
                    for (int j = 0; j < breakList.Count; j++)
                    {
                        if (courseList[i].IsOverlap(breakList[j]) && breakList[j].IsOverlap(courseList[i]))
                        {
                            return true;
                        }
                    }
                }
            }

            var tuples = from i1 in baseList
                         from i2 in baseList
                         where i1 < i2
                         select Tuple.Create(i1, i2);

            foreach (var tuple in tuples)
            {
                numTuples++;
                if (!courseList[tuple.Item1].IsOverlap(courseList[tuple.Item2]))
                {
                    valid++;
                }
            }
            return valid != numTuples;
        }
    }
}