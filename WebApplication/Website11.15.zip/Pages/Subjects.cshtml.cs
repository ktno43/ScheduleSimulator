using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ScheduleSimulator.Code;

namespace ScheduleSimulator.Pages
{
    public class Subjects : PageModel
    {
        CourseDataAccessLayer cDal = new CourseDataAccessLayer();

        public List<String> lstSubject { get; set; }
        public List<Course> lstCourse { get; set; }

        public string Message { get; set; }

        public void OnGet()
        {
            lstSubject = cDal.GetSubj();
            lstCourse = cDal.GetCourseBySubj("COMP");
            Message = "Hello";
        }

        private void FixIllegalChar(ref String refStr)
        {
            String invalidChars = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars()); // Get a string of invalid characters

            foreach (char c in invalidChars)
            {
                refStr = refStr.Replace(c.ToString(), String.Empty); // Remove invalid characters
            }
        }

        [HttpPost]
        public JsonResult OnPostSubjChange(String selVal)
        {
            cDal = new CourseDataAccessLayer();
            List<Course> lstCourse = new List<Course>();
            String subjName = selVal;

            if (subjName != null)
            {
                String validSubj = (subjName.Substring(0, subjName.IndexOf('-')).Trim()).Replace(" ", String.Empty);
                FixIllegalChar(ref validSubj); // Fix any illegal characters

                lstCourse = cDal.GetCourseBySubj(validSubj);
            }

            return new JsonResult(lstCourse);
        }


    }
}