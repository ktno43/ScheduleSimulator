using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ScheduleSimulator.Code;
using HtmlAgilityPack;

namespace ScheduleSimulator.Pages
{
    public class IndexModel : PageModel
    {
        private CourseDataAccessLayer cDal { get; set; }

        public String lastUpdated { get; set; }

        public List<String> lstSubject { get; set; }

        public List<String> lstProf { get; set; }

        public List<List<Course>> lstValidSched { get; set; }

        public string Message { get; set; }

        private void fixIllegalChar(ref String refStr)
        {
            String invalidChars = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars()); // Get a string of invalid characters

            foreach (char c in invalidChars)
            {
                refStr = refStr.Replace(c.ToString(), String.Empty); // Remove invalid characters
            }
        }

        [HttpGet]
        public void OnGet()
        {
            cDal = new CourseDataAccessLayer();
            lstSubject = cDal.GetSubj();
            lastUpdated = cDal.GetUpdateDate();
            lstProf = cDal.GetProf();

            /*
             String pathPropAzure = @"D:\home\site\wwwroot\Properties\appsettings.json"; // Azure root
             String pathWwwAzure = @"D:\home\site\wwwroot\wwwroot\Wallet\sqlnet.ora"; // Azure root

            //String readText = System.IO.File.ReadAllText(@"C:\inetpub\AspNetCoreWebApps\wwwroot\Wallet\sqlnet.ora");
            String pathPropAWS = @"C:\inetpub\AspNetCoreWebApps\app\Properties\appsettings.json"; // AWS properties
            String pathWwwAWS = @"C:\inetpub\AspNetCoreWebApps\app\wwwroot\Wallet\sqlnet.ora"; //AWS root


            String dir = Directory.GetCurrentDirectory();

            String val = ConfigurationManager.AppSetting["TNS_ADMIN:keyAWS"];
            String isExist = System.IO.File.Exists(pathPropAWS) ? "File exists." : "File does not exist.";
            String isExist2 = System.IO.File.Exists(pathWwwAWS) ? "File exists." : "File does not exist.";


            Message = dir + "\r\n" + isExist + "\r\n" + isExist2 + "\r\n" + val +"\r\n"+ System.IO.File.ReadAllText(pathWwwAWS);
            */
            Message = "Hello :)";
        }

        [HttpPost]
        public JsonResult OnPostSubjChange(String selVal)
        {
            cDal = new CourseDataAccessLayer();
            List<String> lstCourse = new List<String>();
            String subjWriteName = selVal;

            if (subjWriteName != null)
            {
                String validSubj = (subjWriteName.Substring(0, subjWriteName.IndexOf('-')).Trim()).Replace(" ", String.Empty);
                fixIllegalChar(ref validSubj); // Fix any illegal characters

                String tblName = ConfigurationManager.AppSetting["TBL_PREFIX:key"]; // tbl prefix
                tblName += validSubj;


                lstCourse = cDal.GetUniqueCourseByTbl(tblName);
            }

            return new JsonResult(lstCourse);
        }

        [HttpPost]
        public JsonResult OnPostGenSched(String[] courseWant, String[] breaks, Boolean cbOpen)
        {
            cDal = new CourseDataAccessLayer();
            List<List<Course>> lstCourseWant = new List<List<Course>>();
            List<CourseBreak> lstBreaks = new List<CourseBreak>();

            for (int i = 0; i < courseWant.Length; i++)
            {
                int idxOfNum = courseWant[i].IndexOfAny("0123456789".ToCharArray());
                String subjWriteName = CleanFileName(courseWant[i].Substring(0, idxOfNum));
                subjWriteName = Regex.Replace(subjWriteName, @"\s+", "");
                String tblName = ConfigurationManager.AppSetting["TBL_PREFIX:key"] + subjWriteName;

                int idxOfDash = courseWant[i].IndexOf('-');
                String courseName = courseWant[i].Substring(0, idxOfDash).Trim();
                List<Course> currentSec = cDal.GetCourseByTbl(tblName, courseName);
                lstCourseWant.Add(currentSec);
            }

            for (int j = 0; j < breaks.Length; j++)
            {
                var html = breaks[j];

                var htmlDoc = new HtmlDocument();
                htmlDoc.LoadHtml(html);

                int idxBreak = 0;
                String days = String.Empty;
                String time = String.Empty;

                foreach (HtmlNode br in htmlDoc.DocumentNode.SelectNodes("//br"))
                {
                    if (idxBreak == 0)
                    {
                        days = br.NextSibling.InnerText.Trim();
                    }

                    else
                    {
                        time = br.NextSibling.InnerText.Trim();
                    }

                    idxBreak++;
                }
                String[] splitDay = days.Split(' ');
                String[] splitTime = time.Split(" to ");
                for (int k = 0; k < splitDay.Length; k++)
                {
                    CourseBreak cBreak = new CourseBreak(splitDay[k], splitTime[0], splitTime[1]);

                    lstBreaks.Add(cBreak);
                }
            }


            List<List<Course>> validSched = GenerateSchedule(lstCourseWant, lstBreaks, cbOpen);
            lstValidSched = validSched;

            return new JsonResult(validSched);
        }

        private static String CleanFileName(String fileName)
        {
            return Path.GetInvalidFileNameChars().Aggregate(fileName, (current, c) => current.Replace(c.ToString(), String.Empty));
        }

        public List<List<Course>> GenerateSchedule(List<List<Course>> courseWant, List<CourseBreak> breakList, Boolean cbOpen)
        {
            Dictionary<String, List<int>> cwDictionary = new Dictionary<String, List<int>>();

            for (int i = 0; i < courseWant.Count; i++)
            {
                List<int> courseNumList = new List<int>();

                for (int j = 0; j < courseWant[i].Count; j++)
                {
                    courseNumList.Add(j);
                }
                cwDictionary.Add(String.Format("Course{0}", i.ToString()), courseNumList);
            }

            List<List<Course>> validSched = new List<List<Course>>();
            List<List<int>> cwNumList = new List<List<int>>();

            foreach (KeyValuePair<String, List<int>> entry in cwDictionary)
            {
                cwNumList.Add(entry.Value);
            }

            var possibleCombos = CartesianProduct(cwNumList);

            foreach (var combo in possibleCombos)
            {
                List<Course> tempSched = new List<Course>();

                for (int k = 0; k < courseWant.Count; k++)
                {
                    tempSched.Add(courseWant[k][combo.ElementAt(k)]);
                }

                if (!IsConflict(tempSched, breakList, cbOpen))
                {
                    validSched.Add(tempSched);
                }
            }

            return PrintSchedule(courseWant, validSched);
        }

        private List<List<Course>> PrintSchedule(List<List<Course>> courseWant, List<List<Course>> validSched)
        {
            int totalSchedules = 1;
            for (int i = 0; i < courseWant.Count; i++)
            {
                totalSchedules *= courseWant[i].Count;
            }

            int possibleSchedules = 0;

            Boolean isEmpty = !validSched.Any();

            if (!isEmpty)
            {
                possibleSchedules = validSched.Count;
            }

            Console.WriteLine("Possible schedule(s): " + possibleSchedules + " out of " + totalSchedules + " possible");
            int schedNum = 1;

            if (possibleSchedules > 0)
            {
                foreach (List<Course> sched in validSched)
                {
                    String schedRes = String.Empty;
                    for (int l = 0; l < courseWant.Count; l++)
                    {
                        if (l < (courseWant.Count - 1))
                        {
                            schedRes += sched[l].courseNum;
                            schedRes += ", ";
                        }

                        else
                        {
                            schedRes += sched[l].courseNum;
                        }
                    }
                    Console.Write(schedNum + ")\t" + schedRes + "\r\n");
                    schedNum++;
                }
            }

            else
            {
                Console.WriteLine("No possible schedules found");
            }

            return validSched;
        }

        private IEnumerable<IEnumerable<T>> CartesianProduct<T>(IEnumerable<IEnumerable<T>> sequences)
        {
            // base case: 
            IEnumerable<IEnumerable<T>> result = new[] { Enumerable.Empty<T>() };
            foreach (var sequence in sequences)
            {
                var s = sequence; // don't close over the loop variable 
                                  // recursive case: use SelectMany to build the new product out of the old one 
                result =
                    from seq in result
                    from item in s
                    select seq.Concat(new[] { item });
            }

            return result;
        }

        private IEnumerable<IEnumerable<T>> CartesianProduct2<T>(IEnumerable<IEnumerable<T>> sequences)
        {
            IEnumerable<IEnumerable<T>> emptyProduct = new[] { Enumerable.Empty<T>() };
            return sequences.Aggregate(
                emptyProduct,
                (accumulator, sequence) =>
                from acc in accumulator
                from item in sequence
                select acc.Concat(new[] { item }));
        }

        private Boolean IsConflict(List<Course> courseList, List<CourseBreak> breakList, Boolean cbOpen)
        {
            Boolean isBreakLstEmpty = !breakList.Any();

            if (courseList.Count == 1 && breakList.Count == 0)
            {
                if (cbOpen)
                {
                    if (!courseList[0].IsOpen(courseList[0]))
                    {
                        return true;
                    }
                }

                return false;
            }

            int valid = 0;
            int numTuples = 0;
            var baseList = new List<int>();

            for (int i = 0; i < courseList.Count; i++)
            {
                baseList.Add(i);

                if (cbOpen)
                {
                    if (!courseList[i].IsOpen(courseList[i]))
                    {
                        return true;
                    }
                }

                if (!isBreakLstEmpty)
                {
                    for (int j = 0; j < breakList.Count; j++)
                    {
                        if (courseList[i].IsOverlap(breakList[j]) && breakList[j].IsOverlap(courseList[i]))
                        {
                            return true;
                        }
                    }
                }
            }

            var tuples = from i1 in baseList
                         from i2 in baseList
                         where i1 < i2
                         select Tuple.Create(i1, i2);

            foreach (var tuple in tuples)
            {
                numTuples++;
                if (!courseList[tuple.Item1].IsOverlap(courseList[tuple.Item2]))
                {
                    valid++;
                }
            }
            return valid != numTuples;
        }
    }
}