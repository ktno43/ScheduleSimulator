﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ScheduleSimulator.Code
{
    public class CourseBreak
    {
        public String mBreakDay { get; set; }

        public String mBStartTime { get; set; }

        public String mBEndTime { get; set; }

        public CourseBreak(String breakDay, String bStartTime, String bEndTime)
        {
            mBreakDay = breakDay;
            mBStartTime = bStartTime;
            mBEndTime = bEndTime;
        }

        public CourseBreak(String breakDay)
        {
            mBreakDay = breakDay;
            mBStartTime = "12:00am";
            mBEndTime = "11:59pm";
        }

        public String[] ParseTime()
        {
            String[] timeArr = new String[6];

            String sHr = this.mBStartTime.Substring(0, 2);
            String sMin = this.mBStartTime.Substring(3, 2);
            String sAmPm = this.mBStartTime.Substring(5, 2);

            String eHr = this.mBEndTime.Substring(0, 2);
            String eMin = this.mBEndTime.Substring(3, 2);
            String eAmPm = this.mBEndTime.Substring(5, 2);

            timeArr[0] = sHr;
            timeArr[1] = sMin;
            timeArr[2] = sAmPm;

            timeArr[3] = eHr;
            timeArr[4] = eMin;
            timeArr[5] = eAmPm;

            return timeArr;
        }

        public Boolean IsOverlap(Course c)
        {
            if (c.IsOnline(c))
            {
                return false;
            }

            else
            {
                if (!c.IsUnknown(c))
                {
                    String[] arrC = this.ParseTime();
                    String[] arrB = c.ParseTime(c);

                    if (IsDayConflict(this, c) && IsTimeConflict(arrC, arrB))
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        private Boolean IsDayConflict(CourseBreak b, Course c)
        {
            String cDay = Regex.Replace(c.courseDay, ".{2}", "$0,").TrimEnd(',');
            String bDay = Regex.Replace(b.mBreakDay, ".{2}", "$0,").TrimEnd(',');

            String[] arrCday = cDay.Split(',');
            String[] arrBday = bDay.Split(',');

            if (arrCday.Length > arrBday.Length)
            {
                if (arrBday.Intersect(arrCday).Any())
                {
                    return true;
                }
            }

            else
            {
                if (arrCday.Intersect(arrBday).Any())
                {
                    return true;
                }
            }
            return false;
        }

        private Boolean IsTimeConflict(String[] t1, String[] t2)
        {
            int t1HrS = Int32.Parse(t1[0]);
            int t1MinS = Int32.Parse(t1[1]);
            DateTime t1TimeS = GetTime(t1HrS, t1MinS, t1[2]);

            int t1HrE = Int32.Parse(t1[3]);
            int t1MinE = Int32.Parse(t1[4]);
            DateTime t1TimeE = GetTime(t1HrE, t1MinE, t1[5]);


            int t2HrS = Int32.Parse(t2[0]);
            int t2MinS = Int32.Parse(t2[1]);
            DateTime t2TimeS = GetTime(t2HrS, t2MinS, t2[2]);

            int t2HrE = Int32.Parse(t2[3]);
            int t2MinE = Int32.Parse(t2[4]);
            DateTime t2TimeE = GetTime(t2HrE, t2MinE, t2[5]);

            return (t1TimeS <= t2TimeE) && (t2TimeS <= t1TimeE);
        }

        private DateTime GetTime(int hour, int minute, String amPm)
        {
            int year = 2019;
            int month = 9;
            int day = 23;

            if ((amPm.Equals("pm") || amPm.Equals("PM")) && hour < 12)
            {
                hour += 12;
            }

            else if ((amPm.Equals("am") || amPm.Equals("AM")) && hour == 12)
            {
                hour = 0;
            }

            return new DateTime(year, month, day, hour, minute, 00);
        }
    }
}
