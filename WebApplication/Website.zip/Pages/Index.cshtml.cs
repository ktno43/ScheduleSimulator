using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ScheduleSimulator.Code;

namespace ScheduleSimulator.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty(SupportsGet = true)]
        public String selectedSubj { get; set; }

        private CourseDataAccessLayer cDal { get; set; }

        public List<Course> courseWant { get; set; }

        public List<String> lstSubject { get; set; }

        public string Message { get; set; }

        private void fixIllegalChar(ref String refStr)
        {
            String invalidChars = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars()); // Get a string of invalid characters

            foreach (char c in invalidChars)
            {
                refStr = refStr.Replace(c.ToString(), String.Empty); // Remove invalid characters
            }
        }

        [HttpGet]
        public void OnGet()
        {
            cDal = new CourseDataAccessLayer();
            lstSubject = cDal.getSubj();
            // String path = @"D:\home\site\wwwroot\wwwroot\Wallet\sqlnet.ora";

            // String readText = System.IO.File.ReadAllText(path);
            Message = "HOME PAGE!!!!";
            //Message = System.IO.File.Exists(path) ? "File exists." : "File does not exist.";

        }

        [HttpPost]
        public JsonResult OnPostSubjChange(String selVal)
        {
            cDal = new CourseDataAccessLayer();
            List<String> lstCourse = new List<String>();
            String subjWriteName = selVal;

            if (subjWriteName != null)
            {
                String validSubj = (subjWriteName.Substring(0, subjWriteName.IndexOf('-')).Trim()).Replace(" ", String.Empty);
                fixIllegalChar(ref validSubj); // Fix any illegal characters

                String tblName = ConfigurationManager.AppSetting["TBL_PREFIX:key"]; // tbl prefix
                tblName += validSubj;


                lstCourse = cDal.getUniqueCourseByTbl(tblName);
            }

            return new JsonResult(lstCourse);
        }
    }
}