﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.
// Add slideDown animation to Bootstrap dropdown when expanding.

$(function () {
    $('#course_select').selectpicker('hide');

    $('#modalBreak').on('hidden.bs.modal', function () {
        $('#formBreak').trigger("reset");
    })

    $("#course_select").change(function () {
        var x = this.selectedIndex;

        if (x == -1) {
            $("#btnAdd").hide();
        } else {
            $("#btnAdd").show();
        }
    })

    $(function () {
        $('#subj_select').change(function () {
            $('#course_select').selectpicker('show');
            $('#course_select').selectpicker('deselectAll');

            var selVal = $("#subj_select").val();
            $.ajax({
                //url: "/?handler=SubjChange&selVal=" + selVal,
                url: "/Index?handler=SubjChange&selVal=" + selVal,
                type: "POST",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("XSRF-TOKEN",
                        $('input:hidden[name="__RequestVerificationToken"]').val());
                },
                success: function (data) {
                    $("#course_select").empty();

                    for (var i in data) {
                        $('#course_select').append('<option value="' + data[i] + '">' + data[i] + '</option>');
                    }

                    $("#course_select").selectpicker("refresh");
                }
            });
        });
    })

    $("#btnBreakAdd").click(function () {
        $('#modalBreak').modal('toggle');
        $('#lblAddBreak').show();
        $("#tblSched tr").remove();

        var tblBreak = document.getElementById("tblBreak");

        if (!document.getElementById("tboxBreak").value) {
            alert("Empty");
        }

        else {
            var breakName = $('#tboxBreak').val();

            var sTimeH = $('#selStartH').val();
            var sTimeM = $('#selStartM').val();
            var sTimeAmPm = $("input[name='sAmPm']:checked", '#formBreak').val();
            var sTime = sTimeH.concat(":", sTimeM, sTimeAmPm);


            var eTimeH = $('#selEndH').val();
            var eTimeM = $('#selEndM').val();
            var eTimeAmPm = $("input[name='eAmPm']:checked", '#formBreak').val();
            var eTime = eTimeH.concat(":", eTimeM, eTimeAmPm);

            var time = sTime.concat(" to ", eTime);
            var days = "";

            var daysOfWeek = ["checkboxMon", "checkboxTue", "checkboxWed", "checkboxThu", "checkboxFri", "checkboxSat", "checkboxSun"];

            for (var i = 0; i < daysOfWeek.length; i++) {
                if ($('#' + daysOfWeek[i]).is(":checked", '#formBreak')) {
                    days += $('#' + daysOfWeek[i]).val() + " ";
                }
            }


            var row = tblBreak.insertRow(-1);
            var rowBreak = document.createElement("br");
            var rowBreak2 = document.createElement("br");

            var tdBreak = document.createElement('td');
            tdBreak.colSpan = "2";

            var breakNameTxtB = document.createElement('b');
            breakNameTxtB.innerText = breakName;
            tdBreak.appendChild(breakNameTxtB);

            tdBreak.appendChild(rowBreak);

            var breakDays = document.createTextNode(days);
            tdBreak.appendChild(breakDays);

            tdBreak.appendChild(rowBreak2);


            var breakTimeI = document.createElement('i');
            breakTimeI.innerText = time;
            tdBreak.append(breakTimeI);

            row.appendChild(tdBreak);

            var tdBtn = document.createElement('td');
            tdBtn.colSpan = "1";
            var btnRemove = $("<button class=\"btn btn-danger btn-remove \" type=\"button\"><i class= \"fas fa-minus-circle\" ></i></button>")
            btnRemove.appendTo(tdBtn);
            row.appendChild(tdBtn);

            tblBreak.append(row);
        }
    });

    $(function () {
        $(document).on('click', '.btn-add', function () {
            $('#lblAddCourse').show();

            var selectedValues = $('#course_select').val();

            var tblCourseWant = document.getElementById("tblCourseWant");

            var isBreak = false;
            var repeatCourse = [];

            for (var i = 0; i < selectedValues.length; i++) {
                var course = selectedValues[i];
                var courseId = course.substring(0, course.indexOf("-")).trim();
                var courseIdFix = course.substring(0, course.indexOf("-")).replace(/ /g, '').replace(/([^a-z0-9]+)/gi, '');
                var eleExist = document.getElementById(courseIdFix);

                if (eleExist == null) {
                    var row = tblCourseWant.insertRow(-1);
                    var tdCourse = document.createElement('td');
                    tdCourse.colSpan = "2";
                    var divCourse = document.createElement('div');
                    var courseText = document.createTextNode(selectedValues[i]);
                    divCourse.id = courseIdFix;
                    divCourse.appendChild(courseText);
                    tdCourse.appendChild(divCourse);
                    row.appendChild(tdCourse);

                    var tdBtn = document.createElement('td');
                    var btnRemove = $("<button class=\"btn btn-danger btn-remove \" type=\"button\"><i class= \"fas fa-minus-circle\" ></i></button>")
                    tdBtn.colSpan = "1";
                    btnRemove.appendTo(tdBtn);
                    row.appendChild(tdBtn);

                    tblCourseWant.append(row);

                    $('#btnGenSched').show();
                }

                else {
                    isBreak = true;
                    repeatCourse.push(courseId);
                }
            }

            if (isBreak) {
                if (repeatCourse.length == 1) {
                    alert("Course " + repeatCourse[0] + " was already added.");
                }

                else {
                    var repeatStr;

                    if (repeatCourse.length == 2) {
                        repeatStr = repeatCourse.join(" and ");
                    }

                    else {
                        repeatStr = repeatCourse.join(", ");
                        repeatStr = repeatStr.replace(/,(?=[^,]*$)/, ', and')
                    }

                    alert("Courses "
                        + repeatStr
                        + " were already added."
                    );
                }
            }

        }).on('click', '.btn-remove', function () {
            $(this).closest("tr").remove();
            $("#tblSched tr").remove();

            if ($('#tblCourseWant tr').length > 0) {
                $('#btnGenSched').show();
            }

            else {
                $('#lblAddCourse').hide();
                $('#btnGenSched').hide();
            }

            if ($('#tblBreak tr').length > 0) {
                $('#lblAddBreak').show();
            }

            else {
                $('#lblAddBreak').hide();

            }

            return false;
        });
    });

    $('#btnGenSched').click(function () {
        var courseData = [];
        var tblCourse = $('#tblCourseWant tr');

        tblCourse.each(function (idx, td) {
            courseData.push($(td).text());
        });
        var breakData = [];

        var tblBreak = $('#tblBreak tr');
        tblBreak.each(function (itx, td) {
            breakData.push($(td).html());
        });


        $.ajax({
            url: "/Index?handler=GenSched",
            data: {
                'courseWant': courseData, 'breaks': breakData
            },
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("XSRF-TOKEN",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            },
            success: function (data) {
                if (data.length > 0) {
                    $("#tblSched tr").remove();

                    var tblSched = document.getElementById("tblSched");

                    var headerList = ["Course", "Section", "Course Number", "Location", "Days", "Start Time", "End Time", "Instructor"]
                    var thColSpan = ["1", "3", "1", "1", "1", "1", "1", "2"]
                    var scheduleNum = 1;

                    for (var i in data) {
                        var row = tblSched.insertRow(-1);
                        var td = document.createElement('td');
                        td.bgColor = "#1685c0";
                        td.style.color = "#ffffff";
                        td.colSpan = "11";
                        var boldText = document.createElement("B");
                        var schedule = document.createTextNode("Schedule #" + scheduleNum);
                        boldText.appendChild(schedule);
                        td.appendChild(boldText);
                        row.appendChild(td);
                        tblSched.append(row);

                        row = tblSched.insertRow(-1);
                        for (var k = 0; k < headerList.length; k++) {
                            var th = document.createElement('th');

                            th.colSpan = thColSpan[k];
                            th.className = "border";
                            var txtHeader = document.createTextNode(headerList[k]);
                            th.appendChild(txtHeader);
                            row.appendChild(th);
                        }

                        tblSched.appendChild(row);

                        for (var j in data[i]) {
                            row = tblSched.insertRow(-1);
                            var cell1 = row.insertCell(0);
                            cell1.className = "border";
                            cell1.colSpan = "1";

                            var cell2 = row.insertCell(1);
                            cell2.className = "border";
                            cell2.colSpan = "3";

                            var cell3 = row.insertCell(2);
                            cell3.className = "border";
                            cell3.colSpan = "1";

                            var cell4 = row.insertCell(3);
                            cell4.className = "border";
                            cell4.colSpan = "1";

                            var cell5 = row.insertCell(4);
                            cell5.className = "border";
                            cell5.colSpan = "1";

                            var cell6 = row.insertCell(5);
                            cell6.className = "border";
                            cell6.colSpan = "1";

                            var cell7 = row.insertCell(6);
                            cell7.className = "border";
                            cell7.colSpan = "1";

                            var cell8 = row.insertCell(7);
                            cell8.className = "border";
                            cell8.colSpan = "2";

                            cell1.innerHTML = data[i][j].courseSec;
                            cell2.innerHTML = data[i][j].courseName;
                            cell3.innerHTML = data[i][j].courseNum;
                            cell4.innerHTML = data[i][j].courseLoc;
                            cell5.innerHTML = data[i][j].courseDay;
                            cell6.innerHTML = data[i][j].cStartTime;
                            cell7.innerHTML = data[i][j].cEndTime;
                            cell8.innerHTML = data[i][j].courseInstr;
                        }

                        row = tblSched.insertRow(-1);
                        td = document.createElement('td');
                        td.colSpan = "11";
                        var br = document.createElement("br");
                        td.appendChild(br);
                        row.appendChild(td);
                        tblSched.append(row);

                        scheduleNum += 1;
                    }
                }

                else {
                    $("#tblSched tr").remove();

                    var tblSched = document.getElementById("tblSched");
                    var row = tblSched.insertRow(-1);
                    var td = document.createElement('td');

                    td.className = "border";
                    td.bgColor = "#1685c0";
                    td.style.color = "#ffffff";
                    td.colSpan = "11";

                    var boldText = document.createElement("B");
                    var schedule = document.createTextNode("No Possible Schedules");

                    boldText.appendChild(schedule);
                    td.appendChild(boldText);
                    row.appendChild(td);
                    tblSched.append(row);
                }
            }
        });
    });
})