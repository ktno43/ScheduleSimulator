﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.
// Add slideDown animation to Bootstrap dropdown when expanding.

$(function () {
    var btnEditInc = 0;
    $('#course_select').selectpicker('hide');

    $('#modalBreak').on('hidden.bs.modal', function () {
        $('#formBreak').trigger("reset");
        $("#startLblPm").removeClass('active');
        $("#startLblAm").addClass('active');

        $("#endLblAm").removeClass('active');
        $("#endLblPm").addClass('active');

    })

    $("#course_select").change(function () {
        var x = this.selectedIndex;

        if (x == -1) {
            $("#btnAdd").hide();
        } else {
            $("#btnAdd").show();
        }
    })

    $('#selectWeekday').click(function (event) {
        if (this.checked) {
            $('#checkboxMon').prop('checked', true);
            $('#checkboxTue').prop('checked', true);
            $('#checkboxWed').prop('checked', true);
            $('#checkboxThu').prop('checked', true);
            $('#checkboxFri').prop('checked', true);
        } else {
            $('#checkboxMon').prop('checked', false);
            $('#checkboxTue').prop('checked', false);
            $('#checkboxWed').prop('checked', false);
            $('#checkboxThu').prop('checked', false);
            $('#checkboxFri').prop('checked', false);
        }
    })

    $('#selectWeekdayEdit').click(function (event) {
        if (this.checked) {
            $('#checkboxMonE').prop('checked', true);
            $('#checkboxTueE').prop('checked', true);
            $('#checkboxWedE').prop('checked', true);
            $('#checkboxThuE').prop('checked', true);
            $('#checkboxFriE').prop('checked', true);
        } else {
            $('#checkboxMonE').prop('checked', false);
            $('#checkboxTueE').prop('checked', false);
            $('#checkboxWedE').prop('checked', false);
            $('#checkboxThuE').prop('checked', false);
            $('#checkboxFriE').prop('checked', false);
        }
    })

    $(function () {
        $('#subj_select').change(function () {
            $('#course_select').selectpicker('show');
            $('#course_select').selectpicker('deselectAll');

            var selVal = $("#subj_select").val();
            $.ajax({
                //url: "/?handler=SubjChange&selVal=" + selVal,
                url: "/Index?handler=SubjChange&selVal=" + selVal,
                type: "POST",
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("XSRF-TOKEN",
                        $('input:hidden[name="__RequestVerificationToken"]').val());
                },
                success: function (data) {
                    $("#course_select").empty();

                    for (var i in data) {
                        $('#course_select').append('<option value="' + data[i] + '">' + data[i] + '</option>');
                    }

                    $("#course_select").selectpicker("refresh");
                }
            });
        });
    })

    $("#btnBreakAdd").click(function () {
        $('#modalBreak').modal('toggle');

        var tblBreak = document.getElementById("tblBreak");

        if (!document.getElementById("tboxBreak").value) {
            alert("Empty");
        }

        else {
            $('#lblAddBreak').show();
            $("#tblSched tr").remove();

            var breakName = $('#tboxBreak').val();

            var sTimeH = $('#selStartH').val();
            var sTimeM = $('#selStartM').val();
            var sTimeAmPm = $("input[name='sAmPm']:checked", '#formBreak').val();
            var sTime = sTimeH.concat(":", sTimeM, sTimeAmPm);


            var eTimeH = $('#selEndH').val();
            var eTimeM = $('#selEndM').val();
            var eTimeAmPm = $("input[name='eAmPm']:checked", '#formBreak').val();
            var eTime = eTimeH.concat(":", eTimeM, eTimeAmPm);

            var time = sTime.concat(" to ", eTime);
            var days = "";

            var daysOfWeek = ["checkboxMon", "checkboxTue", "checkboxWed", "checkboxThu", "checkboxFri", "checkboxSat", "checkboxSun"];

            for (var i = 0; i < daysOfWeek.length; i++) {
                if ($('#' + daysOfWeek[i]).is(":checked", '#formBreak')) {
                    days += $('#' + daysOfWeek[i]).val() + " ";
                }
            }


            var row = tblBreak.insertRow(-1);
            var rowBreak = document.createElement("br");
            var rowBreak2 = document.createElement("br");

            var tdBreak = document.createElement('td');
            tdBreak.colSpan = "1";
            tdBreak.className = "sched";

            var breakNameTxtB = document.createElement('b');
            breakNameTxtB.innerText = breakName;
            tdBreak.appendChild(breakNameTxtB);

            tdBreak.appendChild(rowBreak);

            var breakDays = document.createTextNode(days);
            tdBreak.appendChild(breakDays);

            tdBreak.appendChild(rowBreak2);


            var breakTimeI = document.createElement('i');
            breakTimeI.innerText = time;
            tdBreak.append(breakTimeI);

            row.appendChild(tdBreak);


            var tdBtn = document.createElement('td');
            tdBtn.colSpan = "1";
            var btnEdit = $("<button class=\"btn btn-warning btn-edit\" data-id=\"btnEditId" + btnEditInc + "\" data-toggle=\"modal\" data-target=\"#modalBreakEdit\" id=\"btnEditId" + btnEditInc + "\" type=\"button\"><i class=\"fas fa-pen\"></i>");
            btnEdit.appendTo(tdBtn);
            row.appendChild(tdBtn);
            btnEditInc += 1;
            tblBreak.append(row);


            tdBtn = document.createElement('td');
            tdBtn.colSpan = "1";
            var btnRemove = $("<button class=\"btn btn-danger btn-remove \" type=\"button\"><i class= \"fas fa-minus-circle\" ></i></button>");
            btnRemove.appendTo(tdBtn);
            row.appendChild(tdBtn);

            tblBreak.append(row);

        }
    });

    $('#modalBreakEdit').on('show.bs.modal', function (event) {
        var myVal = $(event.relatedTarget).data('id');
        $('input[name="editId"]').val(myVal);
    });

    $("#btnBreakSave").click(function (e) {
        if (!document.getElementById("tboxBreakEdit").value) {
            alert("Empty");
        }

        else {
            $('#lblAddBreak').show();
            $("#tblSched tr").remove();

            var breakName = $('#tboxBreakEdit').val();

            var sTimeH = $('#selEditStartH').val();
            var sTimeM = $('#selEditStartM').val();
            var sTimeAmPm = $("input[name='sEditAmPm']:checked", '#formBreakEdit').val();
            var sTime = sTimeH.concat(":", sTimeM, sTimeAmPm);


            var eTimeH = $('#selEditEndH').val();
            var eTimeM = $('#selEditEndM').val();
            var eTimeAmPm = $("input[name='eEditAmPm']:checked", '#formBreakEdit').val();
            var eTime = eTimeH.concat(":", eTimeM, eTimeAmPm);

            var time = sTime.concat(" to ", eTime);
            var days = "";

            var daysOfWeek = ["checkboxMonE", "checkboxTueE", "checkboxWedE", "checkboxThuE", "checkboxFriE", "checkboxSatE", "checkboxSunE"];

            for (var i = 0; i < daysOfWeek.length; i++) {
                if ($('#' + daysOfWeek[i]).is(":checked", '#formBreakEdit')) {
                    days += $('#' + daysOfWeek[i]).val() + " ";
                }
            }

            var editBtn = $('input[name="editId"]').val();

            var td = $('#' + editBtn).parent().siblings(":first");
            td.html("<b>" + breakName + "</b>"
                + "<br>" + days + "<br>"
                + "<i>" + time + "</i>");
        }

        $('#modalBreakEdit').modal('toggle');
    });

    $(function () {
        $(document).on('click', '.btn-edit', function () {
            var td = $(this).parent().siblings(":first");
            var tdText = td.html();

            var idxOpenB = tdText.indexOf("<b>") + 3;
            var idxCloseB = tdText.indexOf("</b>");
            var breakName = tdText.slice(idxOpenB, idxCloseB);

            var idxFirstBr = tdText.indexOf("<br>") + 4;
            var idxLastBr = tdText.lastIndexOf("<br>") - 1;
            var days = tdText.slice(idxFirstBr, idxLastBr);
            var daysArr = days.split(" ");

            var idxOpenI = tdText.indexOf("<i>") + 3;
            var idxStartTime = tdText.indexOf(':');
            var sHour = tdText.slice(idxOpenI, idxStartTime);

            var idxTo = tdText.indexOf(" to ");
            var sMin = tdText.slice(idxStartTime + 1, idxTo - 2);

            var sAmPm = tdText.slice(idxTo - 2, idxTo);

            var idxEndTime = tdText.lastIndexOf(':');
            var eHour = tdText.slice(idxTo + 4, idxEndTime);
            var idxCloseI = tdText.indexOf("</i>");
            var eMin = tdText.slice(idxEndTime + 1, idxCloseI - 2);

            var eAmPm = tdText.slice(idxCloseI - 2, idxCloseI)

            $('#tboxBreakEdit').val(breakName);
            $('#selEditStartH').val(sHour);
            $('#selEditStartM').val(sMin);

            if (sAmPm == "AM") {
                $('#radioEditStartAm').prop('checked', true);
                $('#radioEditStartPm').prop('checked', false);
                $("#startEditLblAm").addClass('active');
                $("#startEditLblPm").removeClass('active');
            }

            else {
                $('#radioEditStartPm').prop('checked', true);
                $('#radioEditStartAm').prop('checked', false);
                $("#startEditLblPm").addClass('active');
                $("#startEditLblAm").removeClass('active');
            }

            $('#selEditEndH').val(eHour);
            $('#selEditEndM').val(eMin);

            if (eAmPm == "AM") {
                $('#radioEditEndAm').prop('checked', true);
                $('#radioEditEndPm').prop('checked', false);
                $("#endEditLblAm").addClass('active');
                $("#endEditLblPm").removeClass('active');
            }

            else {
                $('#radioEditEndPm').prop('checked', true);
                $('#radioEditEndAm').prop('checked', false);
                $("#endEditLblPm").addClass('active');
                $("#endEditLblAm").removeClass('active');
            }

            for (var i = 0, k = 0; i < daysArr.length; i++) {
                switch (daysArr[i]) {
                    case "Mo":
                        $('#checkboxMonE').prop('checked', true);
                        k += 1;
                        break;

                    case "Tu":
                        $('#checkboxTueE').prop('checked', true);
                        k += 1;
                        break;

                    case "We":
                        $('#checkboxWedE').prop('checked', true);
                        k += 1;
                        break;

                    case "Th":
                        $('#checkboxThuE').prop('checked', true);
                        k += 1;
                        break;

                    case "Fr":
                        $('#checkboxFriE').prop('checked', true);
                        k += 1;
                        break;

                    case "Sa":
                        $('#checkboxSatE').prop('checked', true);
                        break;

                    case "Su":
                        $('#checkboxSunE').prop('checked', true);
                        break;
                }

                if (k == 5) {
                    $('#selectWeekdayEdit').prop('checked', true);
                }

                else {
                    $('#selectWeekdayEdit').prop('checked', false);
                }
            }
        });
    })

    $(function () {
        $(document).on('click', '.btn-add', function () {
            $('#lblAddCourse').show();

            var selectedValues = $('#course_select').val();

            var tblCourseWant = document.getElementById("tblCourseWant");

            var isBreak = false;
            var repeatCourse = [];

            for (var i = 0; i < selectedValues.length; i++) {
                var course = selectedValues[i];
                var courseId = course.substring(0, course.indexOf("-")).trim();
                var courseIdFix = course.substring(0, course.indexOf("-")).replace(/ /g, '').replace(/([^a-z0-9]+)/gi, '');
                var eleExist = document.getElementById(courseIdFix);

                if (eleExist == null) {
                    var row = tblCourseWant.insertRow(-1);
                    var tdCourse = document.createElement('td');
                    tdCourse.colSpan = "2";
                    var divCourse = document.createElement('div');
                    var courseText = document.createTextNode(selectedValues[i]);
                    divCourse.id = courseIdFix;
                    divCourse.appendChild(courseText);
                    tdCourse.appendChild(divCourse);
                    row.appendChild(tdCourse);

                    var tdBtn = document.createElement('td');
                    var btnRemove = $("<button class=\"btn btn-danger btn-remove \" type=\"button\"><i class= \"fas fa-minus-circle\" ></i></button>")
                    tdBtn.colSpan = "1";
                    btnRemove.appendTo(tdBtn);
                    row.appendChild(tdBtn);

                    tblCourseWant.append(row);

                    $('#btnGenSched').show();
                }

                else {
                    isBreak = true;
                    repeatCourse.push(courseId);
                }
            }

            if (isBreak) {
                if (repeatCourse.length == 1) {
                    alert("Course " + repeatCourse[0] + " was already added.");
                }

                else {
                    var repeatStr;

                    if (repeatCourse.length == 2) {
                        repeatStr = repeatCourse.join(" and ");
                    }

                    else {
                        repeatStr = repeatCourse.join(", ");
                        repeatStr = repeatStr.replace(/,(?=[^,]*$)/, ', and')
                    }

                    alert("Courses "
                        + repeatStr
                        + " were already added."
                    );
                }
            }

        }).on('click', '.btn-remove', function () {
            $(this).closest("tr").remove();
            $("#tblSched tr").remove();
            btnEditInc -= 1;

            if ($('#tblCourseWant tr').length > 0) {
                $('#btnGenSched').show();
            }

            else {
                $('#lblAddCourse').hide();
                $('#btnGenSched').hide();
            }

            if ($('#tblBreak tr').length > 0) {
                $('#lblAddBreak').show();
            }

            else {
                $('#lblAddBreak').hide();

            }

            return false;
        });
    });

    $('#btnGenSched').click(function () {
        var courseData = [];
        var tblCourse = $('#tblCourseWant tr');

        tblCourse.each(function (idx, td) {
            courseData.push($(td).text());
        });
        var breakData = [];

        var tblBreak = $('#tblBreak tr');
        tblBreak.each(function (itx, td) {
            breakData.push($(td).html());
        });


        $.ajax({
            url: "/Index?handler=GenSched",
            data: {
                'courseWant': courseData, 'breaks': breakData
            },
            type: "POST",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("XSRF-TOKEN",
                    $('input:hidden[name="__RequestVerificationToken"]').val());
            },
            success: function (data) {
                if (data.length > 0) {
                    $("#tblSched tr").remove();

                    var tblSched = document.getElementById("tblSched");

                    var headerList = ["Course", "Section", "Course Number", "Location", "Days", "Start Time", "End Time", "Instructor"]
                    var thColSpan = ["1", "3", "1", "1", "1", "1", "1", "2"]
                    var scheduleNum = 1;

                    for (var i in data) {
                        var row = tblSched.insertRow(-1);
                        var td = document.createElement('td');
                        td.bgColor = "#1685c0";
                        td.style.color = "#ffffff";
                        td.colSpan = "11";
                        var boldText = document.createElement("B");
                        var schedule = document.createTextNode("Schedule #" + scheduleNum);
                        boldText.appendChild(schedule);
                        td.appendChild(boldText);
                        row.appendChild(td);
                        tblSched.append(row);

                        row = tblSched.insertRow(-1);
                        for (var k = 0; k < headerList.length; k++) {
                            var th = document.createElement('th');

                            th.colSpan = thColSpan[k];
                            th.className = "border sched";
                            var txtHeader = document.createTextNode(headerList[k]);
                            th.appendChild(txtHeader);
                            row.appendChild(th);
                        }

                        tblSched.appendChild(row);

                        for (var j in data[i]) {
                            row = tblSched.insertRow(-1);
                            var cell1 = row.insertCell(0);
                            cell1.className = "border sched";
                            cell1.colSpan = "1";

                            var cell2 = row.insertCell(1);
                            cell2.className = "border sched";
                            cell2.colSpan = "3";

                            var cell3 = row.insertCell(2);
                            cell3.className = "border sched";
                            cell3.colSpan = "1";

                            var cell4 = row.insertCell(3);
                            cell4.className = "border sched";
                            cell4.colSpan = "1";

                            var cell5 = row.insertCell(4);
                            cell5.className = "border sched";
                            cell5.colSpan = "1";

                            var cell6 = row.insertCell(5);
                            cell6.className = "border sched";
                            cell6.colSpan = "1";

                            var cell7 = row.insertCell(6);
                            cell7.className = "border sched";
                            cell7.colSpan = "1";

                            var cell8 = row.insertCell(7);
                            cell8.className = "border sched";
                            cell8.colSpan = "2";

                            cell1.innerHTML = data[i][j].courseSec;
                            cell2.innerHTML = data[i][j].courseName;
                            cell3.innerHTML = data[i][j].courseNum;
                            cell4.innerHTML = data[i][j].courseLoc;
                            cell5.innerHTML = data[i][j].courseDay;
                            cell6.innerHTML = data[i][j].cStartTime;
                            cell7.innerHTML = data[i][j].cEndTime;
                            cell8.innerHTML = data[i][j].courseInstr;
                        }

                        row = tblSched.insertRow(-1);
                        td = document.createElement('td');
                        td.colSpan = "11";
                        var br = document.createElement("br");
                        td.appendChild(br);
                        row.appendChild(td);
                        tblSched.append(row);

                        scheduleNum += 1;
                    }
                }

                else {
                    $("#tblSched tr").remove();

                    var tblSched = document.getElementById("tblSched");
                    var row = tblSched.insertRow(-1);
                    var td = document.createElement('td');

                    td.className = "border";
                    td.bgColor = "#1685c0";
                    td.style.color = "#ffffff";
                    td.colSpan = "11";

                    var boldText = document.createElement("B");
                    var schedule = document.createTextNode("No Possible Schedules");

                    boldText.appendChild(schedule);
                    td.appendChild(boldText);
                    row.appendChild(td);
                    tblSched.append(row);
                }
            }
        });
    });
})