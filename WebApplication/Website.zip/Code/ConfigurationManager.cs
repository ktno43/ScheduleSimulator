﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ScheduleSimulator.Code
{
    static public class ConfigurationManager
    {
        public static IConfiguration AppSetting { get; }

        static ConfigurationManager()
        {
            AppSetting = new ConfigurationBuilder()
                      .SetBasePath(Directory.GetCurrentDirectory() + "\\Properties")
                      //.SetBasePath("D:\\home\\site\\wwwroot\\Properties") //AZURE
                    .AddJsonFile("appsettings.json")
                    .Build();
        }
    }
}
