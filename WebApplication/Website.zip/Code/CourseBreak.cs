﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ScheduleSimulator.Code
{
    public class CourseBreak
    {
        public String mBreakDay { get; set; }

        public String mBStartTime { get; set; }

        public String mBEndTime { get; set; }

        public CourseBreak(String breakDay, String bStartTime, String bEndTime)
        {
            mBreakDay = breakDay;
            mBStartTime = bStartTime;
            mBEndTime = bEndTime;
        }

        public CourseBreak(String breakDay)
        {
            mBreakDay = breakDay;
            mBStartTime = "12:00am";
            mBEndTime = "11:59pm";
        }

        public String[] ParseTime()
        {
            String[] timeArr = new String[6];

            String sHr = this.mBStartTime.Substring(0, 2);
            String sMin = this.mBStartTime.Substring(3, 2);
            String sAmPm = this.mBStartTime.Substring(5, 2);

            String eHr = this.mBEndTime.Substring(0, 2);
            String eMin = this.mBEndTime.Substring(3, 2);
            String eAmPm = this.mBEndTime.Substring(5, 2);

            timeArr[0] = sHr;
            timeArr[1] = sMin;
            timeArr[2] = sAmPm;

            timeArr[3] = eHr;
            timeArr[4] = eMin;
            timeArr[5] = eAmPm;

            return timeArr;
        }
    }
}
