﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace ScheduleSimulator.Code
{
    public class CourseDataAccessLayer
    {
        //ORACLE INSTANCE CLIENT KYLE.ORCL
        private string connectionString = null;

        public CourseDataAccessLayer()
        {
            // connectionString = "Data Source=csuncoursesdb_high;User Id=ADMIN;Password=Password123!";
            connectionString = ConfigurationManager.AppSetting["ConnectionStrings:OracleConnection"];
        }

        public String GetUpdateDate()
        {
            String tblSubj = ConfigurationManager.AppSetting["tblSubject:key"];
            String lastUpdated = String.Empty;

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "SELECT CREATIONDATE FROM " + tblSubj;

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();

                        reader.Read();

                        lastUpdated = reader["CREATIONDATE"].ToString();
                        DateTime parseDate = DateTime.Parse(lastUpdated);

                        TimeZoneInfo pacificZone = TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time");
                        DateTime pacificTime = TimeZoneInfo.ConvertTimeFromUtc(parseDate, pacificZone);


                        lastUpdated = pacificTime.ToString("ddd, dd MMM. yyy hh':'mm':'ss tt 'PST'");

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lastUpdated;

        }

        public List<String> GetSubj()
        {
            List<String> lstSubject = new List<String>();
            String tblSubj = ConfigurationManager.AppSetting["tblSubject:key"];
            String subject = String.Empty;

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "SELECT SUBJECT FROM " + tblSubj + " ORDER BY SUBJECT";

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            subject = reader["SUBJECT"].ToString();
                            lstSubject.Add(subject);
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstSubject;
        }

        public List<Course> GetCourseBySubj(String subj)
        {
            String tblName = ConfigurationManager.AppSetting["tblSpring2020:key"];

            List<Course> lstCourse = new List<Course>();

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "SELECT SECTION,NAME,COURSENUM,SEAT,AVAILABILITY,LOCATION,DAY,STARTTIME,ENDTIME,INSTRUCTOR FROM "
                            + tblName + "WHERE SUBJECT='" + subj + "' ORDER BY SECTION";

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            Course myCourse = new Course();

                            myCourse.courseSec = reader["SECTION"].ToString();
                            myCourse.courseName = reader["NAME"].ToString();
                            myCourse.courseNum = reader["COURSENUM"].ToString();
                            myCourse.courseSeat = reader["SEAT"].ToString();
                            myCourse.courseAvail = reader["AVAILABILITY"].ToString();
                            myCourse.courseLoc = reader["LOCATION"].ToString();
                            myCourse.courseDay = reader["DAY"].ToString();
                            myCourse.cStartTime = reader["STARTTIME"].ToString();
                            myCourse.cEndTime = reader["ENDTIME"].ToString();
                            myCourse.courseInstr = reader["INSTRUCTOR"].ToString();

                            lstCourse.Add(myCourse);

                            //   Response.WriteAsync("Employee First Name: " + reader.GetString(0) + "\n");
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstCourse;
        }

        public List<String> GetUniqueCourseBySubj(String subj)
        {
            String tblName = ConfigurationManager.AppSetting["tblSpring2020:key"];

            List<String> lstCourse = new List<String>();
            String course = String.Empty;

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "SELECT DISTINCT SECTION, NAME FROM " + tblName + " WHERE SUBJECT='" + subj + "' ORDER BY SECTION";

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            course = reader["SECTION"].ToString();
                            course += " - " + reader["NAME"].ToString();
                            lstCourse.Add(course);

                            //   Response.WriteAsync("Employee First Name: " + reader.GetString(0) + "\n");
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstCourse;
        }

        public List<String> GetUniqueCourseByProf(String prof)
        {
            String tblName = ConfigurationManager.AppSetting["tblSpring2020:key"];

            List<String> lstCourse = new List<String>();
            String course = String.Empty;

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        cmd.CommandText = "SELECT DISTINCT SECTION, NAME FROM " + tblName + " WHERE INSTRUCTOR='" + prof + "' ORDER BY SECTION";

                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            course = reader["SECTION"].ToString();
                            course += " - " + reader["NAME"].ToString();
                            lstCourse.Add(course);
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstCourse;
        }

        public List<Course> GetSectionByCourse(String courseName)
        {
            String tblName = ConfigurationManager.AppSetting["tblSpring2020:key"];

            List<Course> lstCourse = new List<Course>();

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "SELECT SECTION,NAME,COURSENUM,SEAT,AVAILABILITY,LOCATION,DAY,STARTTIME,ENDTIME,INSTRUCTOR FROM "
                            + tblName + " WHERE SECTION='" + courseName + "' ORDER BY SECTION";

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            Course myCourse = new Course();

                            myCourse.courseSec = reader["SECTION"].ToString();
                            myCourse.courseName = reader["NAME"].ToString();
                            myCourse.courseNum = reader["COURSENUM"].ToString();
                            myCourse.courseSeat = reader["SEAT"].ToString();
                            myCourse.courseAvail = reader["AVAILABILITY"].ToString();
                            myCourse.courseLoc = reader["LOCATION"].ToString();
                            myCourse.courseDay = reader["DAY"].ToString();
                            myCourse.cStartTime = reader["STARTTIME"].ToString();
                            myCourse.cEndTime = reader["ENDTIME"].ToString();
                            myCourse.courseInstr = reader["INSTRUCTOR"].ToString();


                            lstCourse.Add(myCourse);

                            //   Response.WriteAsync("Employee First Name: " + reader.GetString(0) + "\n");
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }
            return lstCourse;
        }

        public List<Course> GetSectionByCourseAndProf(String courseName, String profName)
        {
            String tblName = ConfigurationManager.AppSetting["tblSpring2020:key"];

            List<Course> lstCourse = new List<Course>();

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        //Use the command to display employee names from 
                        // the EMPLOYEES table
                        cmd.CommandText = "SELECT SECTION,NAME,COURSENUM,SEAT,AVAILABILITY,LOCATION,DAY,STARTTIME,ENDTIME,INSTRUCTOR FROM "
                            + tblName + " WHERE SECTION='" + courseName + "' AND INSTRUCTOR='" + profName + "' ORDER BY SECTION";

                        // Assign id to the department number 50 
                        //   OracleParameter id = new OracleParameter("id", 50);
                        // cmd.Parameters.Add(id);

                        //Execute the command and use DataReader to display the data
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            Course myCourse = new Course();

                            myCourse.courseSec = reader["SECTION"].ToString();
                            myCourse.courseName = reader["NAME"].ToString();
                            myCourse.courseNum = reader["COURSENUM"].ToString();
                            myCourse.courseSeat = reader["SEAT"].ToString();
                            myCourse.courseAvail = reader["AVAILABILITY"].ToString();
                            myCourse.courseLoc = reader["LOCATION"].ToString();
                            myCourse.courseDay = reader["DAY"].ToString();
                            myCourse.cStartTime = reader["STARTTIME"].ToString();
                            myCourse.cEndTime = reader["ENDTIME"].ToString();
                            myCourse.courseInstr = reader["INSTRUCTOR"].ToString();


                            lstCourse.Add(myCourse);

                            //   Response.WriteAsync("Employee First Name: " + reader.GetString(0) + "\n");
                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }
            return lstCourse;
        }

        public List<String> GetProf()
        {
            List<String> lstInstr = new List<String>();
            String instructor = String.Empty;

            String tblName = ConfigurationManager.AppSetting["tblSpring2020:key"];

            using (OracleConnection con = new OracleConnection(connectionString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;

                        cmd.CommandText = "SELECT DISTINCT INSTRUCTOR FROM " + tblName + " WHERE INSTRUCTOR<>'Staff' ORDER BY INSTRUCTOR";

                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            instructor = reader["INSTRUCTOR"].ToString();
                            lstInstr.Add(instructor);

                        }

                        reader.Dispose();
                        con.Close();
                    }

                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }
                }
            }

            return lstInstr;
        }
    }
}

